#include "pch.h"
#include "Juego.h"

using namespace Proyecto;
int main() {
	Application::EnableVisualStyles();
	Application::Run(gcnew Juego());
	return 0;
}
