#include "pch.h"
#include "Jugador.h"

Jugador::Jugador(int x, int y) {
    ix = x;
    iy = y;
    this->x = x;
	this->y = y;
	vx = 0;
	vy = 0;
	ancho = 18;
	alto = 26;
	indx = 0;
	indy = 0;

	direccion = Direcciones::Ninguna;
	ultima = Direcciones::Abajo;

    muertes = 0;
}
Jugador::~Jugador() {
}

void Jugador::setdireccion(Direcciones direccion) {
	this->direccion = direccion;
}

void Jugador::moverJugador(Graphics^ g, Bitmap^ bmpJugador,int**matriz) {
    direccion == Arriba ? ancho = 17 : ancho = 18;
    switch (direccion) {
    case (Direcciones::Arriba):
        indy = 0;

        if (indx >= 1 && indx < 3)
            indx++;
        else
            indx = 1;
        vx = 0;
        vy = -10;
        ultima = Arriba;
        break;
    case (Direcciones::Abajo):
        indx = 0;

        if (indy >= 1 && indy < 3)
            indy++;
        else
            indy = 1;
        vx = 0;
        vy = 10;
        ultima = Abajo;
        break;
    case (Direcciones::Izquierda):
        indy = 3;

        if (indx >= 1 && indx < 3)
            indx++;
        else
            indx = 1;
        vx = -10;
        vy = 0;
        ultima = Izquierda;
        break;
    case (Direcciones::Derecha):
        indy = 1;

        if (indx >= 1 && indx < 3)
            indx++;
        else
            indx = 1;
        vx = 10;
        vy = 0;
        ultima = Derecha;
        break;
    case (Direcciones::Ninguna):
        vx = 0;
        vy = 0;
        if (ultima == Direcciones::Abajo) {
            indx = 0;
            indy = 2;
        }
        if (ultima == Direcciones::Arriba) {
            indx = 0;
            indy = 0;
        }
        if (ultima == Direcciones::Derecha) {
            indx = 1;
            indy = 1;
        }
        if (ultima == Direcciones::Izquierda) {
            indx = 1;
            indy = 3;
        }
        break;
    default:
        break;
    }
    dibujarJugador(g, bmpJugador,matriz);
}

void Jugador::choquerect(Graphics^ g,int** matriz) {
    int X = 0;
    int Y = 0;
    for (int i = 0; i < filas; i++){ 
        X = 0; 
        for (int j = 0; j < columnas; j++){
            Rectangle c1 = Rectangle(X, Y, 50, 50); 
            if (matriz[i][j] == 1 || matriz[i][j] == 3) {
                if (DI.IntersectsWith(c1))vx = 0;  
                if (AA.IntersectsWith(c1))vy = 0;  
            }
            //g->DrawRectangle(Pens::Red, c1);
            X += 50; 
        }
        Y += 50; 
    }
    
}

void Jugador::dibujarJugador(Graphics^ g, Bitmap^ bmpJugador,int**matriz) {
    DI = Rectangle(x + (2 * 2) + vx, y + (15 * 2), (ancho - 4) * 2, (alto - 15) * 2);
    AA = Rectangle(x + (2 * 2), y + (15 * 2) + vy, (ancho - 4) * 2, (alto - 15) * 2);
    //g->DrawRectangle(Pens::Red, DI);
    //g->DrawRectangle(Pens::Blue, AA);

    choquerect(g,matriz);

    Rectangle uso = Rectangle(indx * ancho, indy * alto, ancho, alto);
    Rectangle aumento = Rectangle(x, y, ancho * 2, alto * 2);
    g->DrawImage(bmpJugador, aumento, uso, GraphicsUnit::Pixel );
    x += vx;
    y += vy;
}

int Jugador::getx() {
    return x + 2 * 2;
}

int Jugador::gety() {
    return y + 15 * 2;
}

void Jugador::contarmuertes(int puntaizquierda, int puntaderecha, int centroiy, int centrofy, int puntaarriba, int puntaabajo, int centroix, int centrofx) {
    if (getx() >= puntaizquierda && getx() <= puntaderecha && gety() >= centroiy && gety() <= centrofy) {
        x = ix;
        y = iy;
        muertes++;
    }
    if (gety() >= puntaarriba && gety() <= puntaabajo && getx() >= centroix && getx() <= centrofx) {
        x = ix;
        y = iy;
        muertes++;
    }
}

int Jugador::getmuertes() {
    return muertes;
}