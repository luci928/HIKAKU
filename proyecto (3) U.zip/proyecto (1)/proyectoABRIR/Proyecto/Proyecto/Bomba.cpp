#include "pch.h"
#include "Bomba.h"

Bomba::Bomba(int x, int y) {
	this->x = x;
	this->y = y;
	estado = Estado::normal;
    ancho = 22;
	alto = 24;
	indx = 0;
	tiempoexplotar = 0;

    index = 0;
    indey = 0;
    anchoe = 80 / 4;
    altoe = 160 / 8;
}

Bomba::~Bomba() {

}
bool Bomba::validarbomba(int xJugador, int yJugador, int** matriz) {
	if (matriz[yJugador / 50][xJugador / 50] == 0 || matriz[yJugador / 50][xJugador / 50] == 2) {
		return true;
	}
	else {
		return false;
	}
}

void Bomba::dibujarbomba(Graphics^ g, Bitmap^ bmpBomba, int xJugador, int yJugador, int** matriz) {
	if (validarbomba(xJugador, yJugador, matriz) == true) {
		Rectangle uso = Rectangle(indx * ancho, 0, ancho, alto);
		Rectangle aumento = Rectangle(x, y, 30, 30);
		g->DrawImage(bmpBomba, aumento, uso, GraphicsUnit::Pixel);
	}
	if (tiempoexplotar == 15) {
		estado = Estado::explosion;
	}
}

void Bomba::animar() {
	if (indx >= 0 && indx <= 2) {
		indx++;
	}
	else {
		tiempoexplotar++;
		indx = 0;
	}
}

void Bomba::dibujarexplosion(Graphics^ g, Bitmap^ bmpExplosionCentro, int** matriz) {

    Rectangle porcionUsarCentro = Rectangle(index * anchoe, indey * altoe, anchoe, altoe); // indey=0
    Rectangle centro = Rectangle(x, y, 50, 50);
    g->DrawImage(bmpExplosionCentro, centro, porcionUsarCentro, GraphicsUnit::Pixel);
    if (matriz[y / 50][(x - 50) / 50] != 1) {
        Rectangle porcionUsarIzquierda = Rectangle(index * anchoe, indey + 2 * altoe, anchoe, altoe); //indey = 2
        Rectangle izquierda = Rectangle(x - 50, y, 50, 50);
        g->DrawImage(bmpExplosionCentro, izquierda, porcionUsarIzquierda, GraphicsUnit::Pixel);

        if (matriz[y / 50][(x - 50) / 50] == 3) { matriz[y / 50][(x - 50) / 50] = 2; }
    }


    if (matriz[y / 50][(x + 50) / 50] != 1) {
        Rectangle porcionUsarDerecha = Rectangle(index * anchoe, indey + 4 * altoe, anchoe, altoe); //indey = 4
        Rectangle derecha = Rectangle(x + 50, y, 50, 50);
        g->DrawImage(bmpExplosionCentro, derecha, porcionUsarDerecha, GraphicsUnit::Pixel);

        if (matriz[y / 50][(x + 50) / 50] == 3) { matriz[y / 50][(x + 50) / 50] = 2; }

    }
    if (matriz[y / 50][(x + 50) / 50] != 1) {
        Rectangle porcionUsarPuntaDerecha = Rectangle(index * anchoe, indey + 3 * altoe, anchoe, altoe); //indey = 3
        Rectangle Puntaderecha = Rectangle(x + 100, y, 50, 50);
        g->DrawImage(bmpExplosionCentro, Puntaderecha, porcionUsarPuntaDerecha, GraphicsUnit::Pixel);

        if (matriz[y / 50][(x + 100) / 50] == 3 && matriz[y / 50][(x + 50) / 50] != 1)
        {

            matriz[y / 50][(x + 100) / 50] = 2;
        }
    }

    if (matriz[y / 50][(x - 50) / 50] != 1) {
        Rectangle porcionUsarPuntaIzquierda = Rectangle(index * anchoe, indey + 1 * altoe, anchoe, altoe); //indey = 1
        Rectangle Puntaizquierda = Rectangle(x - 100, y, 50, 50);
        g->DrawImage(bmpExplosionCentro, Puntaizquierda, porcionUsarPuntaIzquierda, GraphicsUnit::Pixel);

        if (matriz[y / 50][(x - 100) / 50] == 3 && matriz[y / 50][(x - 50) / 50] != 1)
        {
            matriz[y / 50][(x - 100) / 50] = 2;
        }
    }

    Rectangle porcionUsarVerticales = Rectangle(index * anchoe, indey + 6 * altoe, anchoe, altoe); //indey = 1
    Rectangle VerticalSuperior = Rectangle(x, y - 50, 50, 50);
    Rectangle VerticalInferior = Rectangle(x, y + 50, 50, 50);

    if (matriz[(y - 50) / 50][x / 50] != 1) { g->DrawImage(bmpExplosionCentro, VerticalSuperior, porcionUsarVerticales, GraphicsUnit::Pixel); }
    if (matriz[(y - 50) / 50][x / 50] == 3) { matriz[(y - 50) / 50][x / 50] = 2; }
    if (matriz[(y + 50) / 50][x / 50] != 1) { g->DrawImage(bmpExplosionCentro, VerticalInferior, porcionUsarVerticales, GraphicsUnit::Pixel); }
    if (matriz[(y + 50) / 50][x / 50] == 3) { matriz[(y + 50) / 50][x / 50] = 2; }


    if (matriz[(y - 50) / 50][x / 50] != 1) {
        Rectangle porcionUsarPuntaSuperior = Rectangle(index * anchoe, indey + 5 * altoe, anchoe, altoe); //indey = 5
        Rectangle PuntaSuperior = Rectangle(x, y - 100, 50, 50);
        g->DrawImage(bmpExplosionCentro, PuntaSuperior, porcionUsarPuntaSuperior, GraphicsUnit::Pixel);

        if (matriz[(y - 100) / 50][x / 50] == 3 && matriz[(y - 50) / 50][x / 50] != 1) { matriz[(y - 100) / 50][x / 50] = 2; }
    }


    if (matriz[(y + 50) / 50][x / 50] != 1) {
        Rectangle porcionUsarPuntaInferior = Rectangle(index * anchoe, indey + 7 * altoe, anchoe, altoe); //indey = 7
        Rectangle PuntaInferior = Rectangle(x, y + 100, 50, 50);
        g->DrawImage(bmpExplosionCentro, PuntaInferior, porcionUsarPuntaInferior, GraphicsUnit::Pixel);
        if (matriz[(y + 100) / 50][x / 50] == 3 && matriz[(y + 50) / 50][x / 50] != 1) {
            matriz[(y + 100) / 50][x / 50] = 2;
        }
    }
}

void Bomba::animarexplosion() {
    if (index >= 0 && index <= 3) {
        index++;
    }
    else {
        estado = Estado::desaparecer;
    }
}

Estado Bomba::getestado() {
    return estado;
}

int Bomba::getx() {
    return x;
}

int Bomba::gety() {
    return y;
}