#ifndef __CONTROLADOR_H__
#define __CONTROLADOR_H__
#include "Mapa.h"

class Controlador
{
public: 
	Controlador() {
		mapa = new Mapa();
	}
	~Controlador(){}
	void nivel() {
		mapa->generarMatriz();//genera los valores d la matrizz
	}

	void dibujar(Graphics^ g, Bitmap^ bmpBase, Bitmap^ bmpSolido, Bitmap^ bmpDestruible) {
		mapa->PintarBase(g, bmpBase);
		mapa->PintarMatriz(g, bmpSolido, bmpDestruible);//pinta la matriz segun los valores de generar maatriz linea 17 
	
	}


	
private:
	Mapa* mapa;
	
};

#endif // !__CONTROLADOR_H__

