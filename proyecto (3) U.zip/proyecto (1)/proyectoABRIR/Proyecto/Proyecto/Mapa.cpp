#include "pch.h"
#include "Mapa.h"
Mapa::Mapa() {
    matriz = new int* [filas];
}

Mapa::~Mapa() {
}

void Mapa::generarMatriz() {
    srand((unsigned int)time(NULL));
    for (int i = 0; i < filas; i++){
        matriz[i] = new int[columnas];}
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {

            if (i == 0 || j == 0 || i == filas - 1 || j == columnas - 1) 
                matriz[i][j] = 1;
            else{
                for (int i = 2; i < 7; i++) {
                    for (int j = 2;j < 5; j++) {
                       matriz[i][j] = 3;
                    }
                }

                for (int i = 2; i < 7; i++) {
                    for (int j = 8; j < 11; j++) {
                        matriz[i][j] = 4;
                    }
                }
                        
                 if (i == 4 && j == 6)
                    matriz[i][j] = 1;
                 else
                    matriz[i][j] = 2;
            }
        }
    }
}
//MATRIZ COMPLETA
void Mapa::PintarBase(Graphics^ g, Bitmap^ bmpBase) {
    int X, Y = 0;
    for (int i = 0; i < filas; i++) {
        X = 0;// inicializa para q dinuje desde la izquierda 
        for (int j = 0; j < columnas; j++) {
            if (matriz[i][j] == 0 || matriz[i][j] == 2) {
                g->DrawImage(bmpBase, X, Y, 50, 50); 
            }
            X += 50;
        }
        Y += 50;
    }
}

void Mapa::PintarMatriz(Graphics^ g, Bitmap^ bmpSolido, Bitmap^ bmpDestruible) {     
    int X, Y = 0;
    for (int i = 0; i < filas; i++) {
        X = 0;//inicializa en cero porque sino no sale bien el dibujo 
        for (int j = 0; j < columnas; j++) {
            if (matriz[i][j] == 1)
                g->DrawImage(bmpSolido, X, Y, 50, 50);
            else if (matriz[i][j] == 3)
                    g->DrawImage(bmpDestruible, X, Y, 50, 50);
            else if (matriz[i][j] == 4)
                g->DrawImage(bmpDestruible, X, Y, 50, 50);

            X += 50;
        }
        Y += 50;
    }
}int** Mapa::getMatriz() {
    return matriz;}
