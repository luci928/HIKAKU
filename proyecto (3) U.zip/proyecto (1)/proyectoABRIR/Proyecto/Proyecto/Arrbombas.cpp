#include "pch.h"
#include "Arrbombas.h"

Arrbombas::Arrbombas() {
	totalBombas = 1;
}

Arrbombas::~Arrbombas() {

}

void Arrbombas::crearbomba(int x, int y) {
    if (arregloBombas.size() < totalBombas) {
        Bomba* nueva_bomba = new Bomba(x, y);
        arregloBombas.push_back(nueva_bomba);
    }
}

void Arrbombas::dibujarunabomba(Graphics^ g, Bitmap^ bmpBomba, Bitmap^ bmpExplosion, int xJugador, int yJugador, int** matriz) {
    for (int i = 0; i < arregloBombas.size(); i++) {
        switch (arregloBombas.at(i)->getestado()) {
        case Estado::normal:
            arregloBombas.at(i)->dibujarbomba(g, bmpBomba, xJugador, yJugador, matriz);
            arregloBombas.at(i)->animar();
            break;
        case Estado::explosion:
            arregloBombas.at(i)->dibujarexplosion(g, bmpExplosion, matriz);
            arregloBombas.at(i)->animarexplosion();
            break;
        case Estado::desaparecer:
            arregloBombas.erase(arregloBombas.begin() + i);
            break;
        default:
            break;
        }
    }
}

vector<Bomba*> Arrbombas::getarregloBombas() {
    return arregloBombas;
}