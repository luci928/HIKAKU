#ifndef __JUGADOR_H__
#define __JUGADOR_H__
#include "Mapa.h"
using namespace System::Drawing;
enum Direcciones { Arriba, Abajo, Izquierda, Derecha, Ninguna };

class Jugador:public Mapa{

public:
    Jugador(int x, int y);
    ~Jugador();

    void setdireccion(Direcciones direccion);
	void moverJugador(Graphics^ g, Bitmap^ bmpJugador,int**);
	void dibujarJugador(Graphics^ g, Bitmap^ bmpJugadori,int**);
	void choquerect(Graphics^ g,int**);
	int getx();
	int gety();
	int getmuertes();
	void contarmuertes(int, int, int, int, int, int, int, int);
private:
	int ix;
	int iy;
	int x;
	int y;
	int vx;
	int vy;
	int ancho;
	int alto;
	int indx;
	int indy;
	Direcciones direccion;
	Direcciones ultima;
	Rectangle DI;
	Rectangle AA;
	int muertes;
};
#endif
