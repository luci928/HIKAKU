#ifndef __ARRBOMBAS_H__
#define __ARRBOMBAS_H__
#include "Bomba.h"
#include <vector>
using namespace std;

class Arrbombas {
public:
    Arrbombas();
    ~Arrbombas();

    void crearbomba(int x, int y);
    void dibujarunabomba(Graphics^ , Bitmap^ , Bitmap^ , int , int , int** );
    vector<Bomba*> getarregloBombas();

private:
    vector<Bomba*> arregloBombas;
    int totalBombas;

};


#endif
