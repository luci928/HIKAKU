#ifndef __BOMBA_H__
#define __BOMBA_H__

using namespace System::Drawing;

enum Estado { normal, explosion, desaparecer };

class Bomba {
public:
    Bomba(int , int );
    ~Bomba();
    bool validarbomba(int , int , int** );
    void dibujarbomba(Graphics^, Bitmap^, int, int, int**);
    void animar();
    void dibujarexplosion(Graphics^ , Bitmap^ , int** );
    void animarexplosion();
    Estado getestado();
    int getx();
    int gety();
private: 

    int x;
    int y;
    int ancho;
    int alto;
    int indx; 
    int tiempoexplotar;
    Estado estado;

    int index;
    int indey;
    int altoe;
    int anchoe;

};

#endif __BOMBA_H__
