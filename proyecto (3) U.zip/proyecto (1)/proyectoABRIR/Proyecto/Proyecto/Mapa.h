#ifndef __MAPA_H_
#define __MAPA_H_
#include <ctime>
#include <stdlib.h>
using namespace System::Drawing;

class Mapa {
public:
    Mapa();
    ~Mapa();
    void generarMatriz();
    void PintarBase(Graphics^ g, Bitmap^ bmpBase);
    void PintarMatriz(Graphics^ g, Bitmap^ bmpSolido, Bitmap^ bmpDestruible);
    int** getMatriz();
    

protected:
    int** matriz;
    int filas = 9;
    int columnas = 13;
};
#endif 
