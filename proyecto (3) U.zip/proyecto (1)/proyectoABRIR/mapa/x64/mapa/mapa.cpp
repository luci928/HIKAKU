#include "pch.h" // SOLO PARA VIAUL STUDIO 2015 
#include <iostream>
#include <conio.h>
#include <dos.h>
#include <stdlib.h>
#include <Windows.h>
#include <string>
#include <ctime>

#define arriba 72
#define izquierda 75
#define derecha 77
#define abajo 80
#define esc 27

void gotoxy(int x, int y) {
	HANDLE hcon;
	COORD dwpos;

	dwpos.X = x;
	dwpos.Y = y;
	hcon = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleCursorPosition(hcon, dwpos);
}

void pintar() {
	for (int i = 2; i < 78; i++) {
		gotoxy(i, 3);
		printf("%c", 205);
		gotoxy(i, 35);
		printf("%c", 205);
	}
	for (int i = 4; i < 35; i++) {
		gotoxy(2, i);
		printf("%c", 186);
		gotoxy(77,i);
		printf("%c", 186);
	}
	gotoxy(2, 3);
	printf("%c", 201);
	gotoxy(2, 35);
	printf("%c", 200);
	gotoxy(77, 3);
	printf("%c", 187);
	gotoxy(77, 35);
	printf("%c", 188);
}

int main() {

	pintar();
	system("pause>null");
	return 0;
}