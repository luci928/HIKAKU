#include <ctime>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <iostream>
#include "fichita.h"
#include <time.h>
#ifndef  FICHAM_H
#define FICHAM_H


void ficham() {
    
    int x;
    x = 1 + rand() % (5 - 1);
    return ;
}
#endif